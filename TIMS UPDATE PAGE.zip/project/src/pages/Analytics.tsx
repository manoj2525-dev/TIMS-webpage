import React, { useState, useEffect } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from 'recharts';
import { TrendingUp, Package, Users, AlertTriangle } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

const Analytics: React.FC = () => {
  const { token } = useAuth();
  const [loading, setLoading] = useState(true);

  // Mock data for demonstration
  const stockTrendData = [
    { month: 'Jan', stockIn: 120, stockOut: 80 },
    { month: 'Feb', stockIn: 150, stockOut: 90 },
    { month: 'Mar', stockIn: 180, stockOut: 110 },
    { month: 'Apr', stockIn: 140, stockOut: 95 },
    { month: 'May', stockIn: 200, stockOut: 130 },
    { month: 'Jun', stockIn: 170, stockOut: 115 },
  ];

  const supplierPerformanceData = [
    { name: 'Apple Inc.', onTime: 85, overdue: 15 },
    { name: 'Foxconn', onTime: 70, overdue: 30 },
    { name: 'Samsung', onTime: 90, overdue: 10 },
    { name: 'Xiaomi', onTime: 80, overdue: 20 },
  ];

  const categoryData = [
    { name: 'Smartphones', value: 60, color: '#3B82F6' },
    { name: 'Accessories', value: 25, color: '#10B981' },
    { name: 'Tablets', value: 15, color: '#F59E0B' },
  ];

  useEffect(() => {
    // Simulate loading
    setTimeout(() => setLoading(false), 1000);
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-gray-900">Analytics</h1>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Total Revenue</p>
              <p className="text-2xl font-bold text-gray-900">₹45.2L</p>
              <p className="text-sm text-green-600">+12% this month</p>
            </div>
            <div className="bg-green-100 p-3 rounded-full">
              <TrendingUp className="h-6 w-6 text-green-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Stock Turnover</p>
              <p className="text-2xl font-bold text-gray-900">85%</p>
              <p className="text-sm text-blue-600">+5% this month</p>
            </div>
            <div className="bg-blue-100 p-3 rounded-full">
              <Package className="h-6 w-6 text-blue-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Supplier Score</p>
              <p className="text-2xl font-bold text-gray-900">92%</p>
              <p className="text-sm text-yellow-600">-3% this month</p>
            </div>
            <div className="bg-yellow-100 p-3 rounded-full">
              <Users className="h-6 w-6 text-yellow-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Alert Resolution</p>
              <p className="text-2xl font-bold text-gray-900">78%</p>
              <p className="text-sm text-green-600">+8% this month</p>
            </div>
            <div className="bg-purple-100 p-3 rounded-full">
              <AlertTriangle className="h-6 w-6 text-purple-600" />
            </div>
          </div>
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Stock Trends */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Stock In/Out Trends</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={stockTrendData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip />
              <Line type="monotone" dataKey="stockIn" stroke="#3B82F6" strokeWidth={2} />
              <Line type="monotone" dataKey="stockOut" stroke="#EF4444" strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Category Distribution */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Product Categories</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={categoryData}
                dataKey="value"
                nameKey="name"
                cx="50%"
                cy="50%"
                outerRadius={80}
                label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
              >
                {categoryData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>

        {/* Supplier Performance */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 lg:col-span-2">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Supplier Performance</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={supplierPerformanceData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="onTime" stackId="a" fill="#10B981" name="On Time %" />
              <Bar dataKey="overdue" stackId="a" fill="#EF4444" name="Overdue %" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};

export default Analytics;