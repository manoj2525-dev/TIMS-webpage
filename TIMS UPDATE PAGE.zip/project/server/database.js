import sqlite3 from 'sqlite3';
import bcrypt from 'bcryptjs';

const db = new sqlite3.Database('./inventory.db');

export const initDatabase = () => {
  db.serialize(() => {
    // Users table
    db.run(`
      CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        name TEXT NOT NULL,
        role TEXT DEFAULT 'staff',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Products table
    db.run(`
      CREATE TABLE IF NOT EXISTS products (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        category TEXT NOT NULL,
        price DECIMAL(10,2) NOT NULL,
        stock INTEGER DEFAULT 0,
        reorder_point INTEGER DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Suppliers table
    db.run(`
      CREATE TABLE IF NOT EXISTS suppliers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        phone TEXT,
        email TEXT,
        address TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Orders table
    db.run(`
      CREATE TABLE IF NOT EXISTS orders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        supplier_id INTEGER,
        product_name TEXT NOT NULL,
        status TEXT DEFAULT 'pending',
        notes TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (supplier_id) REFERENCES suppliers (id)
      )
    `);

    // Stock transactions table
    db.run(`
      CREATE TABLE IF NOT EXISTS stock_transactions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        product_id INTEGER,
        type TEXT NOT NULL,
        quantity INTEGER NOT NULL,
        notes TEXT,
        user_id INTEGER,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (product_id) REFERENCES products (id),
        FOREIGN KEY (user_id) REFERENCES users (id)
      )
    `);

    // Seed admin user
    const hashedPassword = bcrypt.hashSync('admin123', 10);
    db.run(`
      INSERT OR IGNORE INTO users (email, password, name, role)
      VALUES ('admin@tims.com', ?, 'Admin User', 'admin')
    `, [hashedPassword]);

    // Seed products
    const products = [
      ['iPhone 14', 'Smartphones', 79999, 20, 5],
      ['iPhone 14 Pro', 'Smartphones', 119999, 10, 3],
      ['iPhone 13', 'Smartphones', 59999, 15, 4],
      ['iPhone SE (2022)', 'Smartphones', 39999, 8, 2]
    ];

    products.forEach(product => {
      db.run(`
        INSERT OR IGNORE INTO products (name, category, price, stock, reorder_point)
        VALUES (?, ?, ?, ?, ?)
      `, product);
    });

    // Seed suppliers
    db.run(`
      INSERT OR IGNORE INTO suppliers (name, phone, email, address)
      VALUES 
        ('Apple Inc.', '+1 408-996-1010', 'suppliers@apple.com', 'Cupertino, CA'),
        ('Foxconn', '+886-2-2268-3466', 'orders@foxconn.com', 'Taiwan')
    `);

    // Seed orders
    db.run(`
      INSERT OR IGNORE INTO orders (supplier_id, product_name, status, notes)
      VALUES 
        (1, 'iPhone 14 Pro shipment', 'pending', 'Expected in 2 weeks'),
        (2, 'iPhone SE components', 'overdue', 'Delayed shipment')
    `);
  });
};

export default db;