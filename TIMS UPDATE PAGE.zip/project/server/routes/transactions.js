import express from 'express';
import db from '../database.js';
import { authenticateToken } from '../middleware/auth.js';

const router = express.Router();

// Get all transactions
router.get('/', authenticateToken, (req, res) => {
  const query = `
    SELECT t.*, p.name as product_name, u.name as user_name
    FROM stock_transactions t
    LEFT JOIN products p ON t.product_id = p.id
    LEFT JOIN users u ON t.user_id = u.id
    ORDER BY t.created_at DESC
    LIMIT 50
  `;

  db.all(query, [], (err, transactions) => {
    if (err) {
      return res.status(500).json({ error: 'Server error' });
    }
    res.json(transactions);
  });
});

// Create transaction (stock in/out)
router.post('/', authenticateToken, (req, res) => {
  const { product_id, type, quantity, notes } = req.body;
  const user_id = req.user.id;

  db.serialize(() => {
    db.run('BEGIN TRANSACTION');
    
    // Insert transaction
    db.run(
      'INSERT INTO stock_transactions (product_id, type, quantity, notes, user_id) VALUES (?, ?, ?, ?, ?)',
      [product_id, type, quantity, notes, user_id],
      function(err) {
        if (err) {
          db.run('ROLLBACK');
          return res.status(500).json({ error: 'Server error' });
        }
        
        // Update product stock
        const stockChange = type === 'in' ? quantity : -quantity;
        db.run(
          'UPDATE products SET stock = stock + ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
          [stockChange, product_id],
          function(err) {
            if (err) {
              db.run('ROLLBACK');
              return res.status(500).json({ error: 'Server error' });
            }
            
            db.run('COMMIT');
            res.json({ message: 'Transaction completed successfully' });
          }
        );
      }
    );
  });
});

export default router;