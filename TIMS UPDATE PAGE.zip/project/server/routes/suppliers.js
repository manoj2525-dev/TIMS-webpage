import express from 'express';
import db from '../database.js';
import { authenticateToken, checkRole } from '../middleware/auth.js';

const router = express.Router();

// Get all suppliers with their orders
router.get('/', authenticateToken, (req, res) => {
  const query = `
    SELECT s.*, 
           COUNT(o.id) as order_count,
           GROUP_CONCAT(
             o.product_name || '|' || o.status || '|' || o.notes || '|' || o.created_at,
             ','
           ) as orders
    FROM suppliers s
    LEFT JOIN orders o ON s.id = o.supplier_id
    GROUP BY s.id
    ORDER BY s.name
  `;

  db.all(query, [], (err, suppliers) => {
    if (err) {
      return res.status(500).json({ error: 'Server error' });
    }
    
    // Parse orders for each supplier
    const suppliersWithOrders = suppliers.map(supplier => ({
      ...supplier,
      orders: supplier.orders ? supplier.orders.split(',').map(orderStr => {
        const [product_name, status, notes, created_at] = orderStr.split('|');
        return { product_name, status, notes, created_at };
      }) : []
    }));
    
    res.json(suppliersWithOrders);
  });
});

// Create supplier
router.post('/', authenticateToken, checkRole(['admin', 'manager']), (req, res) => {
  const { name, phone, email, address } = req.body;
  
  db.run(
    'INSERT INTO suppliers (name, phone, email, address) VALUES (?, ?, ?, ?)',
    [name, phone, email, address],
    function(err) {
      if (err) {
        return res.status(500).json({ error: 'Server error' });
      }
      res.json({ id: this.lastID, name, phone, email, address });
    }
  );
});

// Update supplier
router.put('/:id', authenticateToken, checkRole(['admin', 'manager']), (req, res) => {
  const { name, phone, email, address } = req.body;
  
  db.run(
    'UPDATE suppliers SET name = ?, phone = ?, email = ?, address = ? WHERE id = ?',
    [name, phone, email, address, req.params.id],
    function(err) {
      if (err) {
        return res.status(500).json({ error: 'Server error' });
      }
      res.json({ message: 'Supplier updated successfully' });
    }
  );
});

// Delete supplier
router.delete('/:id', authenticateToken, checkRole(['admin', 'manager']), (req, res) => {
  db.run(
    'DELETE FROM suppliers WHERE id = ?',
    [req.params.id],
    function(err) {
      if (err) {
        return res.status(500).json({ error: 'Server error' });
      }
      res.json({ message: 'Supplier deleted successfully' });
    }
  );
});

export default router;