import express from 'express';
import db from '../database.js';
import { authenticateToken, checkRole } from '../middleware/auth.js';

const router = express.Router();

// Get all orders
router.get('/', authenticateToken, (req, res) => {
  const query = `
    SELECT o.*, s.name as supplier_name
    FROM orders o
    LEFT JOIN suppliers s ON o.supplier_id = s.id
    ORDER BY o.created_at DESC
  `;

  db.all(query, [], (err, orders) => {
    if (err) {
      return res.status(500).json({ error: 'Server error' });
    }
    res.json(orders);
  });
});

// Create order
router.post('/', authenticateToken, checkRole(['admin', 'manager']), (req, res) => {
  const { supplier_id, product_name, status = 'pending', notes } = req.body;
  
  db.run(
    'INSERT INTO orders (supplier_id, product_name, status, notes) VALUES (?, ?, ?, ?)',
    [supplier_id, product_name, status, notes],
    function(err) {
      if (err) {
        return res.status(500).json({ error: 'Server error' });
      }
      res.json({ id: this.lastID, supplier_id, product_name, status, notes });
    }
  );
});

// Update order
router.put('/:id', authenticateToken, checkRole(['admin', 'manager']), (req, res) => {
  const { status, notes } = req.body;
  
  db.run(
    'UPDATE orders SET status = ?, notes = ? WHERE id = ?',
    [status, notes, req.params.id],
    function(err) {
      if (err) {
        return res.status(500).json({ error: 'Server error' });
      }
      res.json({ message: 'Order updated successfully' });
    }
  );
});

export default router;