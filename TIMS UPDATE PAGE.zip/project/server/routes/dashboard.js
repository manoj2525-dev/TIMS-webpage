import express from 'express';
import db from '../database.js';
import { authenticateToken } from '../middleware/auth.js';

const router = express.Router();

// Get dashboard data
router.get('/', authenticateToken, (req, res) => {
  const dashboardData = {};
  
  // Get products count
  db.get('SELECT COUNT(*) as count FROM products', [], (err, result) => {
    if (err) return res.status(500).json({ error: 'Server error' });
    dashboardData.products_count = result.count;
    
    // Get suppliers count
    db.get('SELECT COUNT(*) as count FROM suppliers', [], (err, result) => {
      if (err) return res.status(500).json({ error: 'Server error' });
      dashboardData.suppliers_count = result.count;
      
      // Get alerts count
      db.get('SELECT COUNT(*) as count FROM products WHERE stock <= reorder_point', [], (err, lowStock) => {
        if (err) return res.status(500).json({ error: 'Server error' });
        
        db.get("SELECT COUNT(*) as count FROM orders WHERE status = 'overdue'", [], (err, overdueOrders) => {
          if (err) return res.status(500).json({ error: 'Server error' });
          
          dashboardData.alerts_count = lowStock.count + overdueOrders.count;
          
          // Get recent transactions
          const query = `
            SELECT t.*, p.name as product_name, u.name as user_name
            FROM stock_transactions t
            LEFT JOIN products p ON t.product_id = p.id
            LEFT JOIN users u ON t.user_id = u.id
            ORDER BY t.created_at DESC
            LIMIT 10
          `;
          
          db.all(query, [], (err, transactions) => {
            if (err) return res.status(500).json({ error: 'Server error' });
            
            dashboardData.recent_activity = transactions;
            res.json(dashboardData);
          });
        });
      });
    });
  });
});

export default router;