import express from 'express';
import db from '../database.js';
import { authenticateToken, checkRole } from '../middleware/auth.js';

const router = express.Router();

// Get all products
router.get('/', authenticateToken, (req, res) => {
  const { search, filter } = req.query;
  let query = 'SELECT * FROM products WHERE 1=1';
  const params = [];

  if (search) {
    query += ' AND (name LIKE ? OR category LIKE ?)';
    params.push(`%${search}%`, `%${search}%`);
  }

  if (filter === 'low') {
    query += ' AND stock <= reorder_point';
  } else if (filter === 'out') {
    query += ' AND stock = 0';
  }

  query += ' ORDER BY name';

  db.all(query, params, (err, products) => {
    if (err) {
      return res.status(500).json({ error: 'Server error' });
    }
    res.json(products);
  });
});

// Create product
router.post('/', authenticateToken, checkRole(['admin', 'manager']), (req, res) => {
  const { name, category, price, stock, reorder_point } = req.body;
  
  db.run(
    'INSERT INTO products (name, category, price, stock, reorder_point) VALUES (?, ?, ?, ?, ?)',
    [name, category, price, stock || 0, reorder_point || 0],
    function(err) {
      if (err) {
        return res.status(500).json({ error: 'Server error' });
      }
      res.json({ id: this.lastID, name, category, price, stock, reorder_point });
    }
  );
});

// Update product
router.put('/:id', authenticateToken, checkRole(['admin', 'manager']), (req, res) => {
  const { name, category, price, stock, reorder_point } = req.body;
  
  db.run(
    'UPDATE products SET name = ?, category = ?, price = ?, stock = ?, reorder_point = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
    [name, category, price, stock, reorder_point, req.params.id],
    function(err) {
      if (err) {
        return res.status(500).json({ error: 'Server error' });
      }
      res.json({ message: 'Product updated successfully' });
    }
  );
});

// Delete product
router.delete('/:id', authenticateToken, checkRole(['admin', 'manager']), (req, res) => {
  db.run(
    'DELETE FROM products WHERE id = ?',
    [req.params.id],
    function(err) {
      if (err) {
        return res.status(500).json({ error: 'Server error' });
      }
      res.json({ message: 'Product deleted successfully' });
    }
  );
});

export default router;