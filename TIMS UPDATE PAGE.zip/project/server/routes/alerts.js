import express from 'express';
import db from '../database.js';
import { authenticateToken } from '../middleware/auth.js';

const router = express.Router();

// Get all alerts
router.get('/', authenticateToken, (req, res) => {
  const alerts = [];
  
  // Get low stock alerts
  db.all(
    'SELECT id, name, stock, reorder_point FROM products WHERE stock <= reorder_point',
    [],
    (err, lowStockProducts) => {
      if (err) {
        return res.status(500).json({ error: 'Server error' });
      }
      
      lowStockProducts.forEach(product => {
        alerts.push({
          id: `low-stock-${product.id}`,
          type: 'low_stock',
          title: 'Low Stock Alert',
          message: `${product.name} has low stock (${product.stock} remaining)`,
          severity: product.stock === 0 ? 'high' : 'medium',
          created_at: new Date().toISOString()
        });
      });
      
      // Get overdue orders alerts
      db.all(
        `SELECT o.id, o.product_name, s.name as supplier_name 
         FROM orders o 
         LEFT JOIN suppliers s ON o.supplier_id = s.id 
         WHERE o.status = 'overdue'`,
        [],
        (err, overdueOrders) => {
          if (err) {
            return res.status(500).json({ error: 'Server error' });
          }
          
          overdueOrders.forEach(order => {
            alerts.push({
              id: `overdue-${order.id}`,
              type: 'overdue_order',
              title: 'Overdue Order Alert',
              message: `Order "${order.product_name}" from ${order.supplier_name} is overdue`,
              severity: 'high',
              created_at: new Date().toISOString()
            });
          });
          
          res.json(alerts);
        }
      );
    }
  );
});

export default router;